<?php
// Setting the Default Timezone to Asia/Kolkata
date_default_timezone_set("Asia/Kolkata");

// Helper functions
function tabbedDate($month)	{
	return date('M" y', strtotime($month));
}

function headerDate($month)	{
	return date('F Y', strtotime($month));
}

function matchDate($date) {
	return date('jS M - l', strtotime($date));
}

// Formats the date into Month (For usage in Calender View Schedule)
function calenderTabMonth($month) {
	return date('M', strtotime($month));
}

$prevMonth 		=	$scheduleData['prev_month'];
$currentMonth 	=	$scheduleData['current_month'];
$nextMonth 		=	$scheduleData['next_month'];

$headerCurrentDate	=	headerDate($currentMonth);

$tabbedPrevDate		=	tabbedDate($prevMonth);
$tabbedCurrentDate	=	tabbedDate($currentMonth);
$tabbedNextDate		=	tabbedDate($nextMonth);

$prevScheduleData = get_schedule_date($prevMonth);
$nextScheduleData = get_schedule_date($nextMonth);
?>

<div class="rca-row" id="list-view">
	<div class="rca-column-12">

	 	<!--Widget Inner Starts Here -->
	  	<div class="rca-schedule-widget">
	    	<h2>INTERNATIONAL CRICKET SCHEDULES</h2>
	    
		    <!-- Schedule View Section -->
		    <ul class="rca-tab-list">
		        <li class="rca-tab-link tab-link active" data-tab="htab-1" onclick="changeView(this);">
		        	MONTH
		        </li>
		        <li class="rca-tab-link tab-link" data-tab="htab-2" onclick="changeView(this);">
		        	LIST
		        </li>
	     	</ul>

		    
		    <!-- Calender View Schedule -->
		    <div id="htab-1" class="rca-mini-widget rca-top-border rca-padding rca-tab-content tab-content active">

		    	<?php
		    	/**
		    	 * Months Header Bar
		    	 */
		    	?>
		    	<ul class="rca-tab-list">
		    		<?php
		    			$prevLimit = -1;
		    			$nextLimit = 1;
		    			$tabIncrementer = 1;

		    			tab:		    			
		    			if($prevLimit <= $nextLimit):

		    				//Keep current month as Active Header
		    				if($prevLimit == 0) {
		    					$activeMonth = "active";
		    				} else {
		    					$activeMonth = "";
		    				}
				    		?>

		    				<li class="rca-tab-link <?php echo $activeMonth ?>" data-tab="tab-<?php echo $tabIncrementer; ?>" onclick="showTab(this);">
					    		<?php
			    					$calenderMonth = date('M', strtotime($prevLimit."Months", strtotime($currentMonth)));

			    					echo calenderTabMonth($calenderMonth);
			    					$prevLimit++;
			    					$tabIncrementer++;
			    					goto tab;
			    				?>
		    				</li>
		    				<?php
		    			endif;		    			
		    		?>
			    </ul>


			    <?php
			    /**
			     * Calender Content Section
			     */
			    ?>
			    <?php
			    	$prevLimit = -1;
		    		$nextLimit = 1;
		    		$tabIncrementer = 1;

			    	tabcontent:
			    	if($prevLimit <= $nextLimit):

			    		//Show Current Month Match Schedules as Default
	    				if($prevLimit == 0) {
	    					$activeMonth = "active";
	    				} else {
	    					$activeMonth = "";
	    				}
			    		?>

			    		<div id="tab-<?php echo $tabIncrementer; ?>" class="rca-padding rca-tab-content <?php echo $activeMonth ?>">
				    		
				    		<?php
								$scheduledMatch = get_schedule_date(date('Y-m', strtotime($prevLimit."Months", strtotime($currentMonth))));
								
								$matchSchedules = array();
							?>

							<?php //Outer foreach loop starts here ?>
							<?php foreach($scheduledMatch['months'][0]['days'] as $key => $day): ?>
			      			
								<?php $matchesPerDay = count($day['matches']); ?>

								<?php if($matchesPerDay > 0): ?>

									<?php //Inner foreach loop starts here ?>
									<?php $index = 0; ?>
									<?php foreach($day['matches'] as $index => $match): ?>

										<?php
											// Match Format Conversion
											$matchFormat = $day['matches'][0]['format'];
											if($matchFormat == "one-day") {
												$matchFormat = "#fff9c4";
											} elseif ($matchFormat == "t20") {
												$matchFormat = "#E3F2FD";
											} elseif ($matchFormat == "test") {
												$matchFormat = "#ffebee";
											}

											// Match Time Conversion
											$realMatchTime = $day['matches'][$index]['start_date']['iso'];
										?>

										<?php
											$matchSchedule = array("borderColor"=> $matchFormat, "end"=> $realMatchTime, "title"=>$day['matches'][$index]['short_name'], "start"=>$realMatchTime);
																
											array_push($matchSchedules, $matchSchedule);
										?>

										<?php $index++; ?>
									<?php endforeach; ?>
									<?php //Inner foreach loop ends here ?>

								<?php endif; ?>
							<?php endforeach; ?>
							<?php //Outer foreach loop ends here ?>

							<div id="calendar<?php echo $tabIncrementer; ?>"></div>

							<script type="text/javascript">
								jQuery(document).ready(function($) {
							    	debugger;
								    var year_str = "<?php echo date('Y', strtotime($realMatchTime)); ?>";
								    var month_str = "<?php echo date('n', strtotime($realMatchTime)) ?>";

								    var new_month_str = parseInt(month_str);
								    if (new_month_str < 10) {
								        month_str = "0" + month_str;
								    }
								    if (year_str && month_str) {
								        var show_date = year_str + '-' + month_str + "-" + "01";
								    } else {
								        var show_date = moment().format('YYYY-MM-DD')
								    }
								    
								    // Need to give list of dictionary(Match data)			    
								    var data = JSON.parse('<?php echo json_encode($matchSchedules); ?>');

								    for (var i in data) {
								        data[i].start = moment(data[i].start).format("YYYY-MM-DDTHH:mm:ss");
								        data[i].end = moment(data[i].end).format("YYYY-MM-DDTHH:mm:ss");
								    }

								    $('#calendar<?php echo $tabIncrementer; ?>').fullCalendar({
								        header: {
								            left: '',
								            right: ''
								        },
								        defaultDate: show_date,
								        timeFormat: 'h(:mm)a',
								        editable: false,
								        eventLimit: true, // allow "more" link when too many events
								        events: data
								    });
								});
							</script>
			    		</div>
			    		
			    		<?php
			    			$prevLimit++;
	    					$tabIncrementer++;
	    					goto tabcontent;
			    	endif;
			    ?>
			</div>

			

		    <!-- List View Schedule -->
		    <div id="htab-2" class="rca-mini-widget rca-top-border rca-padding rca-tab-content tab-content">

		    	<ul class="rca-tab-list">
			        <li class="rca-tab-link" data-tab="stab-1" id="prev" onclick="showTab(this);">
			        	<?php echo $tabbedPrevDate; ?>
			        </li>
			        <li class="rca-tab-link active" data-tab="stab-2" id="current" onclick="showTab(this);">
			        	<?php echo $tabbedCurrentDate; ?>
			        </li>
			        <li class="rca-tab-link" data-tab="stab-3" id="next" onclick="showTab(this);">
			        	<?php echo $tabbedNextDate; ?>
			        </li>
		     	</ul>
		      	
		      	<!-- Previous Month Schedule -->
		      	<div id="stab-1" class="rca-padding rca-tab-content">
		        	<?php foreach($prevScheduleData['months'][0]['days'] as $key => $day): ?>
		      			<?php //echo "Day: ".$day['day']."<br>"; ?>
		      			<?php $matchesPerDay = count($day['matches']); ?>

		      			<?php if($matchesPerDay > 0): ?>
			      			<div class="rca-schedule-date">
			      				<h4>
			      					<?php echo matchDate($day['matches'][0]['start_date']['iso']); ?>
			      				</h4>

			      				<?php $index = 0; ?>
				      			<?php foreach($day['matches'] as $index => $match): ?>

				      				<?php
				      					// Match Format Conversion
				      					$matchFormat = $day['matches'][0]['format'];
				      					if($matchFormat == "one-day") {
				      						$matchFormat = "odi";
				      					}

				      					// Match Time Conversion
				      					$realMatchTime = $day['matches'][$index]['start_date']['iso'];
				      					$matchTime = date('h.i A', strtotime($realMatchTime));
				      				?>


				      				<div class="rca-schedule-detail rca-<?php echo $matchFormat; ?>">
				      					<h2>
					              			<a href="#">
					                			<span class="rca-team">
					                				<?php echo $day['matches'][$index]['short_name']; ?>
					                			</span>

					                			<span class="rca-match-time">
					                				<?php echo $matchTime; ?>
					                			</span>
					              			</a>
			            				</h2>
			            				<p>
			            					<?php echo $day['matches'][$index]['related_name'].' - '.$day['matches'][$index]['venue']; ?>
			            				</p>
				      				</div>

				      			<?php $index++; ?>
				      			<?php endforeach; ?>
				      		</div>
			      		<?php endif; ?>
			      	<?php endforeach; ?>  
		      	</div>
		      	
		      	<!-- Curent Month Schedule (Default) -->
		      	<div id="stab-2" class="rca-padding rca-tab-content active">
		      		<?php foreach($scheduleData['months'][0]['days'] as $key => $day): ?>
		      			
		      			<?php $matchesPerDay = count($day['matches']); ?>
		      			<?php if($matchesPerDay > 0): ?>
			      			<div class="rca-schedule-date">
			      				<h4>
			      					<?php echo matchDate($day['matches'][0]['start_date']['iso']); ?>
			      				</h4>

			      				<?php $index = 0; ?>
				      			<?php foreach($day['matches'] as $index => $match): ?>

				      				<?php
				      					// Match Format Conversion
				      					$matchFormat = $day['matches'][0]['format'];
				      					if($matchFormat == "one-day") {
				      						$matchFormat = "odi";
				      					}

				      					// Match Time Conversion
				      					$realMatchTime = $day['matches'][$index]['start_date']['iso'];
				      					$matchTime = date('h.i A', strtotime($realMatchTime));
				      				?>


				      				<div class="rca-schedule-detail rca-<?php echo $matchFormat; ?>">
				      					<h2>
					              			<a href="#">
					                			<span class="rca-team">
					                				<?php echo $day['matches'][$index]['short_name']; ?>
					                			</span>

					                			<span class="rca-match-time">
					                				<?php echo $matchTime; ?>
					                			</span>
					              			</a>
			            				</h2>
			            				<p>
			            					<?php echo $day['matches'][$index]['related_name'].' - '.$day['matches'][$index]['venue']; ?>
			            				</p>
				      				</div>

				      			<?php $index++; ?>
				      			<?php endforeach; ?>
				      		</div>
			      		<?php endif; ?>

			      	<?php endforeach; ?>
		      	</div>

		      	<!-- Next Month Schedule -->
		      	<div id="stab-3" class="rca-padding rca-tab-content">
		      		<?php foreach($nextScheduleData['months'][0]['days'] as $key => $day): ?>
		      			<?php //echo "Day: ".$day['day']."<br>"; ?>
		      			<?php $matchesPerDay = count($day['matches']); ?>

		      			<?php if($matchesPerDay > 0): ?>
			      			<div class="rca-schedule-date">
			      				<h4>
			      					<?php echo matchDate($day['matches'][0]['start_date']['iso']); ?>
			      				</h4>

			      				<?php $index = 0; ?>
				      			<?php foreach($day['matches'] as $index => $match): ?>

				      				<?php
				      					// Match Format Conversion
				      					$matchFormat = $day['matches'][0]['format'];
				      					if($matchFormat == "one-day") {
				      						$matchFormat = "odi";
				      					}

				      					// Match Time Conversion
				      					$realMatchTime = $day['matches'][$index]['start_date']['iso'];
				      					$matchTime = date('h.i A', strtotime($realMatchTime));
				      				?>


				      				<div class="rca-schedule-detail rca-<?php echo $matchFormat; ?>">
				      					<h2>
					              			<a href="#">
					                			<span class="rca-team">
					                				<?php echo $day['matches'][$index]['short_name']; ?>
					                			</span>

					                			<span class="rca-match-time">
					                				<?php echo $matchTime; ?>
					                			</span>
					              			</a>
			            				</h2>
			            				<p>
			            					<?php echo $day['matches'][$index]['related_name'].' - '.$day['matches'][$index]['venue']; ?>
			            				</p>
				      				</div>

				      			<?php $index++; ?>
				      			<?php endforeach; ?>
				      		</div>
			      		<?php endif; ?>
			      	<?php endforeach; ?>
		      	</div>
		    </div>
		</div>
	</div>
</div>


<script type="text/javascript">
	function showTab(event) {
        var sourceParent = event.parentElement.parentElement;
        var sourceChilds = sourceParent.getElementsByClassName("rca-tab-content");
        var sourceLinkParent = sourceParent.getElementsByClassName("rca-tab-link");

        for (var i=0; i < sourceChilds.length; i++) {
          sourceChilds.item(i).classList.remove("active");
        }

        for (var i=0; i < sourceLinkParent.length; i++) {
          sourceLinkParent.item(i).classList.remove("active");
        }

        var dataTab= event.getAttribute("data-tab");
        event.classList.add("active");
        document.getElementById(dataTab).className += ' active';
    }

    function changeView(event) {
        var sourceParent = event.parentElement.parentElement;
        var sourceChilds = sourceParent.getElementsByClassName("tab-content");
        var sourceLinkParent = sourceParent.getElementsByClassName("tab-link");

        for (var i=0; i < sourceChilds.length; i++) {
          sourceChilds.item(i).classList.remove("active");
        }

        for (var i=0; i < sourceLinkParent.length; i++) {
          sourceLinkParent.item(i).classList.remove("active");
        }

        var dataTab= event.getAttribute("data-tab");
        event.classList.add("active");
        document.getElementById(dataTab).className += ' active';
    }
</script>