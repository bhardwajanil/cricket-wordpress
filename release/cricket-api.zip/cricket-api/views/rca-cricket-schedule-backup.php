<style>
	/* calendar */
table.calendar		{ border-left:1px solid #999; }
tr.calendar-row	{  }
td.calendar-day	{ min-height:80px; font-size:11px; position:relative; } * html div.calendar-day { height:80px; }
td.calendar-day:hover	{ background:#eceff5; }
td.calendar-day-np	{ background:#eee; min-height:80px; } * html div.calendar-day-np { height:80px; }
td.calendar-day-head { background:#ccc; font-weight:bold; text-align:center; width:120px; padding:5px; border-bottom:1px solid #999; border-top:1px solid #999; border-right:1px solid #999; }
div.day-number		{ background:#999; padding:5px; color:#fff; font-weight:bold; float:right; margin:-5px -5px 0 0; width:20px; text-align:center; }
/* shared */
td.calendar-day, td.calendar-day-np { width:120px; padding:5px; border-bottom:1px solid #999; border-right:1px solid #999; }

</style>

<?php
// Setting the Default Timezone to Asia/Kolkata
date_default_timezone_set("Asia/Kolkata");

// Helper functions
function tabbedDate($month)	{
	return date('M" y', strtotime($month));
}

function headerDate($month)	{
	return date('F Y', strtotime($month));
}

function matchDate($date) {
	return date('jS M - l', strtotime($date));
}

$prevMonth 		=	$scheduleData['prev_month'];
$currentMonth 	=	$scheduleData['current_month'];
$nextMonth 		=	$scheduleData['next_month'];

$headerCurrentDate	=	headerDate($currentMonth);

$tabbedPrevDate		=	tabbedDate($prevMonth);
$tabbedCurrentDate	=	tabbedDate($currentMonth);
$tabbedNextDate		=	tabbedDate($nextMonth);

$prevScheduleData = get_schedule_date($prevMonth);
$nextScheduleData = get_schedule_date($nextMonth);
?>

<?php

/* draws a calendar */
function draw_calendar($month,$year){

	/* draw table */
	$calendar = '<table cellpadding="0" cellspacing="0" class="calendar">';

	/* table headings */
	$headings = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
	$calendar.= '<tr class="calendar-row"><td class="calendar-day-head">'.implode('</td><td class="calendar-day-head">',$headings).'</td></tr>';

	/* days and weeks vars now ... */
	$running_day = date('w',mktime(0,0,0,$month,1,$year));
	$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
	$days_in_this_week = 1;
	$day_counter = 0;
	$dates_array = array();

	/* row for week one */
	$calendar.= '<tr class="calendar-row">';

	/* print "blank" days until the first of the current week */
	for($x = 0; $x < $running_day; $x++):
		$calendar.= '<td class="calendar-day-np"> </td>';
		$days_in_this_week++;
	endfor;

	/* keep going with days.... */
	for($list_day = 1; $list_day <= $days_in_month; $list_day++):
		$calendar.= '<td class="calendar-day">';
			/* add in the day number */
			$calendar.= '<div class="day-number">'.$list_day.'</div>';

			/** QUERY THE DATABASE FOR AN ENTRY FOR THIS DAY !!  IF MATCHES FOUND, PRINT THEM !! **/
			$calendar.= str_repeat('<p> </p>',2);
			
		$calendar.= '</td>';
		if($running_day == 6):
			$calendar.= '</tr>';
			if(($day_counter+1) != $days_in_month):
				$calendar.= '<tr class="calendar-row">';
			endif;
			$running_day = -1;
			$days_in_this_week = 0;
		endif;
		$days_in_this_week++; $running_day++; $day_counter++;
	endfor;

	/* finish the rest of the days in the week */
	if($days_in_this_week < 8):
		for($x = 1; $x <= (8 - $days_in_this_week); $x++):
			$calendar.= '<td class="calendar-day-np"> </td>';
		endfor;
	endif;

	/* final row */
	$calendar.= '</tr>';

	/* end the table */
	$calendar.= '</table>';
	
	/* all done, return result */
	return $calendar;
}

/* sample usages */

?>
<div class="rca-row" id="list-view">
	<div class="rca-column-12">

	 	<!--Widget Inner Starts Here -->
	  	<div class="rca-schedule-widget">
	    	<h2>INTERNATIONAL CRICKET SCHEDULES</h2>
	    
		    <!-- Header Section -->
		    <div class="rca-schedule-top">
		      <span><?php echo $headerCurrentDate; ?></span>
		      <span class="rca-right">
		        <a class="active" href="#">
		          <span>MONTH</span>
		        </a>
		        <a class="" href="#">
		          <span>LIST</span>
		        </a>
		      </span>
		    </div>

		    <!-- List View Schedule -->
		    <div class="rca-mini-widget rca-top-border hide">

		    	<!-- Header Date Navigations -->
		    	<ul class="rca-tab-list">
			        <li class="rca-tab-link" data-tab="stab-1" id="prev" onclick="showTab(this);">
			        	<?php echo $tabbedPrevDate; ?>
			        </li>
			        <li class="rca-tab-link active" data-tab="stab-2" id="current" onclick="showTab(this);">
			        	<?php echo $tabbedCurrentDate; ?>
			        </li>
			        <li class="rca-tab-link" data-tab="stab-3" id="next" onclick="showTab(this);">
			        	<?php echo $tabbedNextDate; ?>
			        </li>
		     	</ul>
		      	
		      	<!-- Previous Month Schedule -->
		      	<?php get_schedule_data(); ?>

		      	<div id="stab-1" class="rca-padding rca-tab-content">
		        	<?php foreach($prevScheduleData['months'][0]['days'] as $key => $day): ?>
		      			<?php //echo "Day: ".$day['day']."<br>"; ?>
		      			<?php $matchesPerDay = count($day['matches']); ?>

		      			<?php if($matchesPerDay > 0): ?>
			      			<div class="rca-schedule-date">
			      				<h4>
			      					<?php echo matchDate($day['matches'][0]['start_date']['iso']); ?>
			      				</h4>

			      				<?php $index = 0; ?>
				      			<?php foreach($day['matches'] as $index => $match): ?>

				      				<?php
				      					// Match Format Conversion
				      					$matchFormat = $day['matches'][0]['format'];
				      					if($matchFormat == "one-day") {
				      						$matchFormat = "odi";
				      					}

				      					// Match Time Conversion
				      					$realMatchTime = $day['matches'][$index]['start_date']['iso'];
				      					$matchTime = date('h.i A', strtotime($realMatchTime));
				      				?>


				      				<div class="rca-schedule-detail rca-<?php echo $matchFormat; ?>">
				      					<h2>
					              			<a href="#">
					                			<span class="rca-team">
					                				<?php echo $day['matches'][$index]['short_name']; ?>
					                			</span>

					                			<span class="rca-match-time">
					                				<?php echo $matchTime; ?>
					                			</span>
					              			</a>
			            				</h2>
			            				<p>
			            					<?php echo $day['matches'][$index]['related_name'].' - '.$day['matches'][$index]['venue']; ?>
			            				</p>
				      				</div>

				      			<?php $index++; ?>
				      			<?php endforeach; ?>
				      		</div>
			      		<?php endif; ?>
			      	<?php endforeach; ?>  
		      	</div>
		      	
		      	<!-- Curent Month Schedule (Default) -->
		      	<div id="stab-2" class="rca-padding rca-tab-content active">
		      		<?php foreach($scheduleData['months'][0]['days'] as $key => $day): ?>
		      			
		      			<?php $matchesPerDay = count($day['matches']); ?>
		      			<?php if($matchesPerDay > 0): ?>
			      			<div class="rca-schedule-date">
			      				<h4>
			      					<?php echo matchDate($day['matches'][0]['start_date']['iso']); ?>
			      				</h4>

			      				<?php $index = 0; ?>
				      			<?php foreach($day['matches'] as $index => $match): ?>

				      				<?php
				      					// Match Format Conversion
				      					$matchFormat = $day['matches'][0]['format'];
				      					if($matchFormat == "one-day") {
				      						$matchFormat = "odi";
				      					}

				      					// Match Time Conversion
				      					$realMatchTime = $day['matches'][$index]['start_date']['iso'];
				      					$matchTime = date('h.i A', strtotime($realMatchTime));
				      				?>


				      				<div class="rca-schedule-detail rca-<?php echo $matchFormat; ?>">
				      					<h2>
					              			<a href="#">
					                			<span class="rca-team">
					                				<?php echo $day['matches'][$index]['short_name']; ?>
					                			</span>

					                			<span class="rca-match-time">
					                				<?php echo $matchTime; ?>
					                			</span>
					              			</a>
			            				</h2>
			            				<p>
			            					<?php echo $day['matches'][$index]['related_name'].' - '.$day['matches'][$index]['venue']; ?>
			            				</p>
				      				</div>

				      			<?php $index++; ?>
				      			<?php endforeach; ?>
				      		</div>
			      		<?php endif; ?>

			      	<?php endforeach; ?>
		      	</div>

		      	<!-- Next Month Schedule -->
		      	<div id="stab-3" class="rca-padding rca-tab-content">
		      		<?php foreach($nextScheduleData['months'][0]['days'] as $key => $day): ?>
		      			<?php //echo "Day: ".$day['day']."<br>"; ?>
		      			<?php $matchesPerDay = count($day['matches']); ?>

		      			<?php if($matchesPerDay > 0): ?>
			      			<div class="rca-schedule-date">
			      				<h4>
			      					<?php echo matchDate($day['matches'][0]['start_date']['iso']); ?>
			      				</h4>

			      				<?php $index = 0; ?>
				      			<?php foreach($day['matches'] as $index => $match): ?>

				      				<?php
				      					// Match Format Conversion
				      					$matchFormat = $day['matches'][0]['format'];
				      					if($matchFormat == "one-day") {
				      						$matchFormat = "odi";
				      					}

				      					// Match Time Conversion
				      					$realMatchTime = $day['matches'][$index]['start_date']['iso'];
				      					$matchTime = date('h.i A', strtotime($realMatchTime));
				      				?>


				      				<div class="rca-schedule-detail rca-<?php echo $matchFormat; ?>">
				      					<h2>
					              			<a href="#">
					                			<span class="rca-team">
					                				<?php echo $day['matches'][$index]['short_name']; ?>
					                			</span>

					                			<span class="rca-match-time">
					                				<?php echo $matchTime; ?>
					                			</span>
					              			</a>
			            				</h2>
			            				<p>
			            					<?php echo $day['matches'][$index]['related_name'].' - '.$day['matches'][$index]['venue']; ?>
			            				</p>
				      				</div>

				      			<?php $index++; ?>
				      			<?php endforeach; ?>
				      		</div>
			      		<?php endif; ?>
			      	<?php endforeach; ?>
		      	</div>
		    </div>

		    <!-- Calender View Schedule -->
		    <div class="rca-mini-widget rca-top-border">

		    	<ul class="rca-tab-list">
			        <li class="rca-tab-link" data-tab="tab-1" onclick="showTab(this);">Jan</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Feb</li>
			        <li class="rca-tab-link active" data-tab="tab-2" onclick="showTab(this);">Mar</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Apr</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">May</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Jun</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Jul</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Aug</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Sep</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Oct</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Nov</li>
			        <li class="rca-tab-link" data-tab="tab-2" onclick="showTab(this);">Dec</li>
			    </ul>
		      
		      	<div id="tab-1" class="rca-tab-content active">
		      		
		      		<?php echo draw_calendar(9,2016); ?>

		        	<div class="rca-day-calendar">
		          		<div class="rca-row">
			            	<div class="rca-week-day-header">
			              		SUN
		            		</div>
			            	<div class="rca-week-day-header">
			              		MON
		            		</div>
			            	<div class="rca-week-day-header">
			              		TUE
			            	</div>
			            	<div class="rca-week-day-header">
			              		WED
			            	</div>
			            	<div class="rca-week-day-header">
			              		THU
			            	</div>
			            	<div class="rca-week-day-header">
			              		FRI
		            		</div>
			            	<div class="rca-week-day-header">
			              		SAT
			            	</div>
		          		</div>
		          	
			          	<div class="rca-row">
			            	<div class="rca-week-day">
			              		<div class="rca-index">31</div>
			              		<div class="rca-schedule-detail rca-test">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-odi">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              	
			              		<div class="rca-schedule-detail rca-t20">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		<a href="#">More..</a>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">3</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">3</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">3</div>
			              		<div class="rca-schedule-detail rca-test">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-odi">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-t20">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
					                </h2>
					            </div>
		        			    <a href="/widgets.html">More..</a>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">4</div>
			            	</div>

				            <div class="rca-week-day">
				            	<div class="rca-index">5</div>
				            </div>

				            <div class="rca-week-day">
				            	<div class="rca-index">6</div>
				            </div>
				        </div>

			          	<div class="rca-row">
			            	<div class="rca-week-day">
			              		<div class="rca-index">7</div> 
			              		<div class="rca-schedule-detail rca-test">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-odi">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-t20">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		<a href="/widgets.html">More..</a>                   
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">8</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">9</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">10</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">11</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">12</div>
			            	</div>
			            
			            	<div class="rca-week-day">
			              		<div class="rca-index">13</div>
			            	</div>
			        	</div>
			        	
			        	<div class="rca-row">
			            	<div class="rca-week-day">
			              		<div class="rca-index">14</div>                    
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">15</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">16</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">17</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">18</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">19</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">20</div>
			              		<div class="rca-schedule-detail rca-test">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-odi">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-t20">
			                		<h2>
			                  			<a href="/main.html">
		                    				<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		<a href="/widgets.html">More..</a>
			            	</div>
			          	</div>
			          	
			          	<div class="rca-row">
			            	<div class="rca-week-day">
			              		<div class="rca-index">21</div>                    
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">22</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">23</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">24</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">25</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">26</div>
			              		<div class="rca-schedule-detail rca-test">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>		
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-odi">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-t20">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>	
			                		</h2>
			              		</div>
			              		<a href="/widgets.html">More..</a>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">27</div>
		            		</div>
			          	</div>
			          	
			          	<div class="rca-row">
				            <div class="rca-week-day">
				             	<div class="rca-index">28</div>                    
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">29</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">30</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">31</div>
			              		<div class="rca-schedule-detail rca-test">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>	
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-odi">
			                		<h2>
			                  			<a href="/main.html">
			                    			<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>
			                		</h2>
			              		</div>
			              		
			              		<div class="rca-schedule-detail rca-t20">
			                		<h2>
			                  			<a href="/main.html">
		                    				<span class="rca-match-time">06.30 AM</span><span class="rca-team">NZ vs AUS</span>
			                  			</a>	
		                			</h2>
			              		</div>
			              		<a href="/widgets.html">More..</a>
			            	</div>	
			            	
			            	<div class="rca-week-day">
			            		<div class="rca-index">1</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">2</div>
			            	</div>
			            	
			            	<div class="rca-week-day">
			              		<div class="rca-index">3</div>
			            	</div>
			          	</div>
		        	</div>
		    	</div>			
				<div id="tab-2" class="rca-padding rca-tab-content"></div>
			</div> 	
		</div>
	</div>
</div>


<script type='text/javascript'>

	function showTab(event) {
        var sourceParent = event.parentElement.parentElement;
        var sourceChilds = sourceParent.getElementsByClassName("rca-tab-content");
        var sourceLinkParent = sourceParent.getElementsByClassName("rca-tab-link");

        for (var i=0; i < sourceChilds.length; i++) {
          sourceChilds.item(i).classList.remove("active");
        }

        for (var i=0; i < sourceLinkParent.length; i++) {
          sourceLinkParent.item(i).classList.remove("active");
        }

        var dataTab= event.getAttribute("data-tab");
        event.classList.add("active");
        document.getElementById(dataTab).className += ' active';
     }
</script>